interface State {
    public boolean isWithinBoard(int x, int y, int newX, int newY, Piece[][] board);
    State nextState();
}
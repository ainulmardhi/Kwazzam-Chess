public class Main {
    public static void main(String[] args) {
        View view = new View();
        //new GameController(GameBoard model; View view);
    }
}
public class TorXorPiece extends Piece {
    private State state;
    private int moveCount = 0;

    public TorXorPiece(int x, int y, String color, State initialState) {
        super(x, y, color);
        this.state = initialState;
    }

    @Override
    public boolean step(int targetCol, int targetRow, Piece[][] board) {
        if (state.isWithinBoard(x, y, targetCol, targetRow, board)) {
            moveCount++;
            if (moveCount == 2) {
                updateState();
            }
            return true;
        }
        return false;
    }

    private void updateState() {
        state = state.nextState();
        moveCount = 0;
    }
}


// public class Xor extends Piece{
    
    // public Xor(int x, int y, String color) {
        // super(x, y, color);
    // }

    // @Override
    // public boolean step(int targetCol, int targetRow, Piece[][] board) {
        // if (!isWithinBoard(targetCol, targetRow, board)) {
            // return false;
        
            // // if(Maths.abs(targetCol - preCol) == Maths.abs(targetRow - preRow)){
            // //     if(isValidSquare(targetCol, targetRow) && 
            // //     pieceIsOnDiagonalLine(targetCol, targetRow) == false){
            // //         return true;
            // //     }
            // // }
        // }
        // return false;
    // }
// }

public class XorState implements State {
    @Override
    public boolean isWithinBoard(int x, int y, int newX, int newY, Piece[][] board) {
        return Math.abs(newX - x) == Math.abs(newY - y);
    }

    @Override
    public State nextState() {
        return new TorState();
    }
}

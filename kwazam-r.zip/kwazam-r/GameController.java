import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameController {
    private GameBoard model;
    private View view;

    public GameController(GameBoard model, View view) {
        this.model = model;
        this.view = view;

        // add listener to the button
        this.view.menu.addButtonListener(new MenuButtonListener());
    }


    private class MenuButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();

            if (command.equals("New Game")) {
                model.resetBoard();
                view.board.initializeBoard();
            } else if (command.equals("Save Game")) {
                model.saveGame();
            } else if (command.equals("Load Game")) {
                model.loadGame();
                view.board.initializeBoard();
            }
        }
    }
}

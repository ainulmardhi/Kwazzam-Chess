public class GameBoard {
    private Piece[][] board;
    private boolean isBlueTurn;

    public GameBoard() {
        board = new Piece[8][5];
        isBlueTurn = true; // Giliran pertama biru
        setupInitialPositions();
    }

    private void setupInitialPositions() {
        for (int i = 0; i < 5; i++) {
            board[6][i] = new Ram(6, i, "blue");
            board[1][i] = new Ram(1, i, "red");
        }
        board[7][1] = new Biz(7, 1, "blue");
        board[0][1] = new Biz(0, 1, "red");
        board[7][3] = new Biz(7, 3, "blue");
        board[0][3] = new Biz(0, 3, "red");
        board[7][4] = new TorXorPiece(7, 4, "blue", new TorState());
        board[0][0] = new TorXorPiece(0, 0, "red", new TorState());
        board[7][0] = new TorXorPiece(7, 0, "blue", new XorState());
        board[0][4] = new TorXorPiece(0, 4, "red", new XorState());
        board[7][2] = new Sau(7, 2, "blue");
        board[0][2] = new Sau(0, 2, "red");
    }

    public boolean movePiece(int startX, int startY, int endX, int endY) {
        Piece piece = board[startX][startY];
        if (piece != null && piece.step(endX, endY, board)) {
            board[endX][endY] = piece;
            board[startX][startY] = null;
            piece.move(endX, endY);
            toggleTurn();
            return true;
        }
        return false;
    }

    private void toggleTurn() {
        isBlueTurn = !isBlueTurn;
    }

    public Piece[][] getBoardState() {
        return board;
    }

    public void resetBoard() {
        setupInitialPositions();
    }

    public void saveGame() {
        System.out.println("Game Saved");
    }

    public void loadGame() {
        System.out.println("Game Loaded");
    }
}
